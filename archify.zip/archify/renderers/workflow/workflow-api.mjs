import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { renderDiagramHtml, validateCrossCollectionContracts } from '../shared/cli.mjs';
import { validateEngineeringProfile } from '../shared/engineering-profiles.mjs';
import { validateSchema } from '../shared/validator.mjs';
import { verifyRepositoryEvidence } from '../shared/repository-evidence.mjs';
import { prepareDiagramBrandMarks } from '../shared/brand-marks.mjs';
import { withDiagnosticRecordingSuppressed } from '../shared/diagnostics.mjs';
import { compileWorkflow } from './workflow-compiler.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const skillRoot = path.resolve(__dirname, '../..');
let cachedTemplate;

function readTemplate() {
  if (cachedTemplate === undefined) {
    cachedTemplate = fs.readFileSync(path.join(skillRoot, 'assets/template.html'), 'utf8');
  }
  return cachedTemplate;
}

// In-memory counterpart to render-workflow.mjs: preserves document validation
// and resource preparation from loadDiagramWithBrandMarks + compileWorkflow.
// Template/repository reads and remote brand fetches can still perform I/O.
// Never installs the process-level diagnostics boundary: classified failures
// return { ok: false }; unclassified implementation errors still throw.
// The caller owns delivery: nothing here writes a file or claims completion.
export async function renderWorkflow(options = {}) {
  return withDiagnosticRecordingSuppressed(() => renderWorkflowInternal(options));
}

async function renderWorkflowInternal({
  workflow,
  qualityProfile,
  repoRoot,
  prepareBrandMarks = true,
} = {}) {
  if (!workflow || typeof workflow !== 'object' || Array.isArray(workflow)) {
    throw new TypeError('renderWorkflow requires one parsed workflow document object.');
  }
  // Clone so a caller's object is never mutated by validation or brand-mark
  // preparation, and so concurrent calls never observe each other's writes.
  const diagram = structuredClone(workflow);
  let sourceEvidence = null;
  try {
    validateSchema('workflow', diagram);
    validateCrossCollectionContracts('workflow', diagram);
    validateEngineeringProfile('workflow', diagram);
    sourceEvidence = verifyRepositoryEvidence('workflow', diagram, repoRoot);
    if (prepareBrandMarks) await prepareDiagramBrandMarks('workflow', diagram);
  } catch (error) {
    if (!error?.archifyDiagnostics?.length) throw error;
    return { ok: false, error: error.message, diagnostics: error.archifyDiagnostics };
  }

  const compiled = compileWorkflow({ workflow: diagram, qualityProfile });
  if (!compiled.ok) {
    return { ok: false, error: compiled.error, diagnostics: compiled.diagnostics, receipt: compiled.receipt };
  }

  const html = renderDiagramHtml({
    diagramType: 'workflow',
    meta: diagram.meta,
    svg: compiled.svg,
    cards: diagram.cards,
    sourceEvidence,
    template: readTemplate(),
  });

  return { ok: true, html, svg: compiled.svg, cards: diagram.cards, meta: diagram.meta, sourceEvidence, receipt: compiled.receipt };
}
